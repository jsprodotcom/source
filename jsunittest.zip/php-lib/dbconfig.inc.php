<?php
/*
 * Database configuration parameters.
 */
 
define("HOSTNAME", "localhost");
define("USERNAME", "username" );
define("PASSWORD", "password" );
define("DATABASE", "appname"  );
?>
