import { generateRandom, sum } from 'utility';

console.log(generateRandom()); //logs a random number

console.log(sum(1,2)); //3