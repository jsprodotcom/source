(function(){
   'use strict';
   require(['main', function(){

   }]);
}());
