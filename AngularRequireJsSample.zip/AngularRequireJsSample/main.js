require(['app/ideasModule'],
    function() {
        'use strict';

        angular.bootstrap(document, ['ideasApp']);
    }
);