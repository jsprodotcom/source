Instructions to run the sample code
-----------------------------------

To run this sample code, you should have [Node.js][1], [NPM][2] and [bower][3] installed. After extracting the zip file on your computer, open a command prompt and change path to the folder containing code. Run the following commands on the command prompt:

 -  npm install
 -  bower install
 -  grunt dev

By now, the Node.js application would have been hosted on the port 3000. Open your web browser and change url to http://localhost:3000. This should display home page of the sample code on the browser.