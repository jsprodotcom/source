##Running the sample code
The sample code doesn't have UI. It has a set of files with some AngularJS code and corresponding test files.

To run the sample, open a command prompt and execute the following commands:

 -  npm install (to install karma package)
 -  bower install (to install front-end packages)
 -  karma start (to start karma and run tests)